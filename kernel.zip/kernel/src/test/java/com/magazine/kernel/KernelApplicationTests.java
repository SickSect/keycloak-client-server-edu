package com.magazine.kernel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KernelApplicationTests {

	@Test
	void contextLoads() {
	}

}
