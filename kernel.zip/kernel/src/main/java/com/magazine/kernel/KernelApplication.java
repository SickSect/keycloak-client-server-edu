package com.magazine.kernel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KernelApplication {

	public static void main(String[] args) {
		SpringApplication.run(KernelApplication.class, args);
	}

}
